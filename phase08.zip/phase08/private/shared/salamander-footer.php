</main>
    
    <footer>
        &copy; <?php echo date('Y'); ?> Southern Appalachian Salamanders
    </footer>
</body>
</html>
<?php 
// Close database connection
db_disconnect($db); 
?>