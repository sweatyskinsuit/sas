<?php
/**
 * Redirect to public directory
 */
header('Location: public/');
exit;